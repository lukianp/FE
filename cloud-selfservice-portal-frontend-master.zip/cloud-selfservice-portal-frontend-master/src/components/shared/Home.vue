<template>
    <div class="hero is-light">
        <div class="hero-body">
            <div class="container">
                <h1 class="title">
                    <i class="material-icons">opacity</i>
                    Cloud Selfservice Portal
                </h1>
            </div>
            <h2 class="subtitle">Willkommen beim Cloud Selfservice Portal. Wähle einen Bereich im Menü aus</h2>
        </div>
    </div>
</template>